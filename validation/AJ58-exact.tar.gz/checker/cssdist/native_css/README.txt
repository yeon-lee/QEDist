CSS search engine

Searches physical CSS check matrices with symmetry reduction, stabilizer-overlap
pruning, packing bounds, kernel-parity reduction and weighted-check bounds.
The package supplies fractional=2 repair-depth=8 even-repairs=4 and checks these
settings in the recorded execution. The fixed support storage accepts up to
8,192 qubits. See ../../docs/native-profiles.md for all input limits.

The optional symmetry-file lists verified qubit-permutation generators.
One root per joint orbit covers product-group actions. The executable checks
both row spaces and reports its root representatives for the Python auditor.
