Lifted-product search engine

This profile uses the CSS search inside each branch. The additional
anchor-site option starts roots at a specified whole-orbit boundary and keeps
all physical coordinates preceding that boundary available. A partial root
range alone cannot establish a full-sector exclusion. The Python campaign
reconstructs a second matrix for the constituent kernel modulo the stabilizers
trivial in every stripe. An exclusion requires both sets of roots and all
their shards to complete. See ../../docs/lp-block-search.md.

An optional symmetry-file supplies physical permutation generators. The native
engine verifies their action on both row spaces and the anchoring block before
computing joint orbits. The Python layer also checks the induced stripe actions.
